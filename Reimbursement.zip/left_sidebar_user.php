 <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a class=" " href="index_user.php" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Homepage </span></a>
                           
                        </li>
                        <li class="nav-label">View</li>
                        <li> <a class="has-arrow   " href="user_profile.php" aria-expanded="false"><i class="fa fa-address-card"></i><span class="hide-menu">Profile</span></a>                            
                        </li>
                        <li> <a class="  " href="user_history.php" aria-expanded="false"><i class="fa fa-file"></i><span class="hide-menu">Claim History</span></a>                            
                        </li>
                        <li> <a class="  " href="change_password.php" aria-expanded="false"><i class="fa fa-lock"></i><span class="hide-menu">Change Password</span></a>                            
                        </li>

                        <li class="nav-label">Claim</li>
                       
                        <li> <a class="  " href="claim_request.php" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">New Claim</span></a>                            
                        </li>
                        
                       
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->